window.MathJax = {
    messageStyle: 'none',
    tex2jax: {
        inlineMath: [
            ['~', '~'],
            ['\\(', '\\)']
        ]
    },
    showMathMenu: false
};